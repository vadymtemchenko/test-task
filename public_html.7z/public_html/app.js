(function() {
    var app = angular.module('monitoring', ["ngAnimate"]);
    
    app.animation(".toggle", function(){
        return {
            leave: function (element, done) {
                TweenMax.to(element, 0.5, {height: 0, onComplete: done});
            },
            enter: function (element, done) {
                TweenMax.from(element, 0.5, {height: 0, onComplete: done});
            }
        };
    });
    
    app.directive('mydataRows', function() {
       return {
           restrict: 'E',
           templateUrl: 'mydata-rows.html'          
       }; 
    });  
    
    app.controller('DataController', ["$http", function($http) {   
        this.data = [];
        var self = this;
        this.currentExpand = null;
        
//        window.setInterval(function (){
            $http.get('data/data.json')
                .success(function (d){
                    self.data = d;
                })
                .error(function () {
                    console.log('error http');
                });
//        }, 5000);
        
        this.getBlockColor = function (state, block) {
            var blockstyle = 'greyblock';
            
            if(state === 'running') return 'blueblock';
            if(block.indicator === 'succeed') {
                blockstyle = 'greenblock';
            } else if (block.indicator === 'fail'){
                blockstyle = 'redblock';
            }
            return blockstyle;
        },
        
        this.preventClick = function (e) {
            e.stopPropagation();
        },
        
        this.showModal = function (e, section, data) {
            e.stopPropagation();
            debugger
//            do something...
        },
        
        this.setExpanded = function (item) {
            if(item.state === "pending" || item.state === "running")
                return false;
            this.currentExpand = this.currentExpand === item.id ? null : item.id;
        };
        
        this.isExpanded = function (id) {
            return this.currentExpand === id;
        };

        this.toggle = function () {
            this.currentExpand = 1;
        },

        this.getStyle = function(state){
            var cname;
            
            switch(state){
                case "accepted":
                case "succeed":
                    cname = 'green';
                    break;
                case "rejected":
                case "fail":
                    cname = 'red';
                    break;
                case "running":
                    cname = 'blue';
                    break;
                default: 
                    cname = 'grey';
                    break;
            }
            
            return cname;
        };
        
        this.getRezColor = function(item){
            var cname;
            
            if(item.type === "firewall"){
                cname = item.state === "accepted" ? "yellow" : "red";
            } else {
                item.state === "succeed" ? "green" : "red";
            }
            
            return cname;
        };
        
    }]);
    
})();